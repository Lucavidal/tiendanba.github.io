let productos = [
    { nombre: "Camiseta Lakers LeBron James", precio: 120000, stock: 10 },
    { nombre: "Zapatillas Jordan Retro", precio: 120000, stock: 5 },
    { nombre: "Pelota Oficial Spalding NBA", precio: 80000, stock: 20 },
    { nombre: "Gorra Boston Celtics", precio: 55000, stock: 15 },
    { nombre: "Camiseta Warriors Stephen Curry", precio: 20000, stock: 12 },
    { nombre: "Gorra Golden State Warriors", precio: 5500, stock: 10 }
];

window.onload = () => {
   
    let precioElemento = document.getElementById("precio");
    if (precioElemento) {
        precioElemento.innerText = "$50000";
    }

    let tituloElemento = document.querySelector("#titulo");
    if (tituloElemento) {
        tituloElemento.style.color = "darkorange";
        tituloElemento.style.fontSize = "28px";
        tituloElemento.style.textAlign = "center";
    }

    
    for (const producto of productos) {
        let h2 = document.createElement("h2");
        h2.innerHTML = producto.nombre;
        document.body.appendChild(h2);
    }

    
    const botonCarrito = document.createElement("button");
    botonCarrito.id = "btnCarrito";
    botonCarrito.innerHTML = "Ver Carrito";
    botonCarrito.style.marginTop = "20px";
    botonCarrito.style.padding = "10px 20px";
    botonCarrito.style.border = "none";
    botonCarrito.style.backgroundColor = "darkorange";
    botonCarrito.style.color = "white";
    botonCarrito.style.cursor = "pointer";
    botonCarrito.style.borderRadius = "5px";
    document.body.appendChild(botonCarrito);

    botonCarrito.addEventListener("click", () => {
        alert("¡Carrito en desarrollo! Pronto podrás ver tus productos aquí.");
    });
};

function mostrarProductos() {
    console.log("Lista de Productos NBA:");
    productos.forEach((producto, index) => {
        console.log(`${index + 1}. ${producto.nombre} - Precio: $${producto.precio} - Stock: ${producto.stock}`);
    });
}


for (let i = 0; i < 3; i++) {
    if (productos.length > 0) {
        let productoVendido = productos.pop();
        console.log(`Se vendió: ${productoVendido.nombre}`);

        productoVendido.stock -= 1;
        if (productoVendido.stock > 0) {
            productos.unshift(productoVendido);
        } else {
            console.log(`El producto ${productoVendido.nombre} se ha agotado.`);
        }
    } else {
        console.log("No hay más productos en stock.");
        break;
    }
}

console.log("Nuevo stock después de la venta:");
mostrarProductos();
